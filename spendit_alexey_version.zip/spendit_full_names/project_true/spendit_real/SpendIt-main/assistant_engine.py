"""SpendIt Assistant: deterministic, explainable intent parsing and catalog reasoning."""
import ast
import datetime as dt
import operator
import re
from urllib.parse import quote_plus


INTENT_WORDS = {
    "greeting": ("привет", "здравствуй", "добрый день", "доброе утро", "добрый вечер", "хай", "hello"),
    "thanks": ("спасибо", "благодарю", "спс"),
    "identity": ("кто ты", "что ты за бот", "что ты такое", "как ты работаешь"),
    "capabilities": ("что ты умеешь", "что умеешь", "помоги", "как пользоваться"),
    "weather": ("погода", "температур", "прогноз", "на улице"),
    "time": ("который час", "сколько времени", "время сейчас", "текущее время"),
    "date": ("какое сегодня число", "какая сегодня дата", "сегодняшняя дата", "какой сегодня день"),
}

CATEGORY_SYNONYMS = {
    "Развлечения": ("отдых", "отдох", "развлеч", "досуг", "весель", "развлекух", "развеяться", "эмоции", "приключения"),
    "Игровые консоли": ("консол", "playstation", "ps5", "xbox", "игровая приставка", "приставку", "приставка"),
    # A casual "игрушка для подростка" can mean a toy, LEGO, board game, or console.
    # Keep this separate from the gaming goal so "игрушка" does not imply PC hardware.
    "Игрушки и игры": ("игруш", "конструктор", "lego", "лего", "настольная игра", "геймпад", "игровая приставка", "playstation", "ps5", "xbox", "консол", "приставк"),
    "Ноутбуки": ("ноут", "ноутбук", "лэптоп", "компьютер для учебы", "компьютер для работы"),
    "Комплектующие": ("комплектующ", "процессор", "видеокарт", "gpu", "cpu", "оператив", "озу", "ssd", "диск", "пк"),
    "Периферия": ("мышь", "мышка", "клавиатур", "перифер", "вебкам", "микрофон"),
    "Наушники": ("наушник", "гарнитур", "airpods", "наушники"),
    "Аудио": ("колонк", "музык", "звук", "портативная акустика"),
    "Смартфоны": ("телефон", "смартфон", "айфон", "iphone", "android", "самсунг"),
    "Смарт-часы": ("умные часы", "смарт часы", "watch", "часы для спорта"),
    "Гаджеты": ("гаджет", "электронная книга", "kindle", "технологи"),
    "Для дома": ("дом", "уборк", "пылесос", "чайник", "кухн", "airfryer", "бытов"),
    "Мебель": ("кресло", "стол", "мебел", "офисное кресло"),
    "Камеры": ("камер", "фото", "фотограф", "gopro", "видео"),
    "Образование": ("обуч", "курс", "учеб", "саморазвит", "книг", "читать", "python"),
    "Спорт": ("спорт", "трениров", "фитнес", "бег", "велосипед", "активн"),
    "Путешествия": ("путешеств", "поездк", "отдых за городом", "тур", "выходные"),
    "Подарки": ("подар", "на день рождения", "сюрприз", "необычн", "оригинальн"),
}

GOAL_SYNONYMS = {
    "gaming": ("игры", "игров", "гейм", "gaming", "fps", "steam", "приставка", "консоль"),
    "work": ("работ", "офис", "продуктив", "монтаж", "програм", "код", "фриланс"),
    "study": ("учеб", "учёб", "школ", "универ", "студент", "курс"),
    "relax": ("отдых", "отдох", "досуг", "развлеч", "релакс", "расслаб", "вечер"),
    "gift": ("подар", "сюрприз", "день рождения", "юбилей", "для брата", "брату", "для сестры", "сестре", "для друга", "другу", "для подростка", "для парня"),
    "home": ("дом", "квартир", "кухн", "уборк"),
    "gift": ("подар", "сюрприз", "необычн", "оригинальн", "удивить"),
}

PRIORITY_WORDS = {
    "cheap": ("дешев", "эконом", "подешевле", "бюджетн", "выгод", "доступн"),
    "performance": ("мощн", "производител", "быстр", "топ", "максимум", "флагман"),
    "quality": ("качеств", "надёж", "надеж", "лучший", "проверен"),
    "balanced": ("оптималь", "сбаланс", "цена/качество", "разумн", "лучшее соотношение"),
    "unique": ("необычн", "оригинальн", "интересн", "удивить", "удивительн", "не как у всех"),
}


def _synonym_match(text, phrase):
    """Match a synonym as a phrase or word prefix, not as arbitrary substring."""
    phrase = str(phrase).strip().lower().replace("ё", "е")
    text = str(text).lower().replace("ё", "е")
    if not phrase:
        return False
    if " " in phrase:
        return phrase in text
    # Match at the beginning of a token so "код" doesn't match "крокодил".
    return re.search(r"(?<![a-zа-я0-9])" + re.escape(phrase) + r"[a-zа-я0-9]*", text) is not None


def _contains(text, words):
    return any(_synonym_match(text, w) for w in words)


def normalize_text(text):
    value = text.lower().strip()
    value = re.sub(r"\bжо\b", "до", value)
    value = value.replace("ё", "е")
    value = re.sub(r"\b(\d+(?:[.,]\d+)?)\s*к\b", lambda m: str(int(float(m.group(1).replace(",", ".")) * 1000)), value)
    value = re.sub(r"\b(\d+(?:[.,]\d+)?)\s*тыс(?:яч|\.)?\b", lambda m: str(int(float(m.group(1).replace(",", ".")) * 1000)), value)
    return value


def parse_budget(text):
    text = normalize_text(text)
    numbers = [int(n.replace(" ", "")) for n in re.findall(r"\d[\d ]{2,}", text)]
    if not numbers:
        numbers = [int(n) for n in re.findall(r"\b\d{3,6}\b", text)]
    if not numbers:
        return None
    if "до" in text or "не больше" in text or "максимум" in text or "в пределах" in text or "не дороже" in text:
        return (0, max(numbers))
    if "от" in text and len(numbers) == 1:
        return (numbers[0], None)
    if len(numbers) >= 2:
        return (min(numbers), max(numbers))
    return (0, numbers[0])


def parse_intent(text):
    lower = normalize_text(text)
    for intent, words in INTENT_WORDS.items():
        if _contains(lower, words):
            return intent
    return "catalog"


def infer_categories(text):
    found = []
    lower = normalize_text(text)
    for category, words in CATEGORY_SYNONYMS.items():
        score = sum(1 for word in words if _synonym_match(lower, word))
        if score:
            found.append((category, score))
    return sorted(found, key=lambda x: x[1], reverse=True)


def infer_goal(text):
    lower = normalize_text(text)
    found = []
    for goal, words in GOAL_SYNONYMS.items():
        score = sum(1 for word in words if _synonym_match(lower, word))
        if score:
            found.append((goal, score))
    return sorted(found, key=lambda x: x[1], reverse=True)[0][0] if found else None


def infer_priority(text):
    lower = normalize_text(text)
    for priority, words in PRIORITY_WORDS.items():
        if _contains(lower, words):
            return priority
    return "balanced"


def tokenise(text):
    stop = {"до", "для", "что", "есть", "мне", "хочу", "нужен", "нужна", "можно", "какой", "какую", "чтобы", "и", "или", "на", "в", "с", "по", "крутой", "крутую", "крутое", "молодежную", "молодёжную", "молодежный", "молодёжный", "брата", "брату", "сестры", "сестре", "друга", "другу"}
    return [x for x in re.findall(r"[a-zа-яё0-9-]+", text.lower()) if len(x) > 2 and x not in stop]


def _is_generic_gift_request(query):
    """True for a broad gift request without a named product or recipient."""
    text = normalize_text(query)
    if not _contains(text, GOAL_SYNONYMS["gift"]):
        return False
    specific = {
        "смартфон", "телефон", "наушник", "колонка", "часы", "книга", "kindle",
        "конструктор", "lego", "лего", "игрушка", "приставка", "консоль", "парфюм",
        "косметика", "рюкзак", "велосипед", "планшет", "ноутбук", "камера", "гаджет",
    }
    return not any(_synonym_match(text, word) for word in specific)


def _safe_calc(expr):
    operators = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv, ast.Mod: operator.mod, ast.Pow: operator.pow}
    tree = ast.parse(expr, mode="eval")
    def calc(node):
        if isinstance(node, ast.Expression): return calc(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)): return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in operators: return operators[type(node.op)](calc(node.left), calc(node.right))
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            value = calc(node.operand)
            return value if isinstance(node.op, ast.UAdd) else -value
        raise ValueError
    return calc(tree)


def _product_text(product):
    return " ".join([
        str(getattr(product, "name", "")),
        str(getattr(product, "category", "")),
        str(getattr(product, "desc", "")),
        str(getattr(product, "details", "")),
        str(getattr(product, "tags", "")),
    ]).lower()


def rank_products(products, query, user=None):
    lower = query.lower()
    tokens = tokenise(query)
    categories = dict(infer_categories(query))
    goal = infer_goal(query)
    priority = infer_priority(query)
    if priority == "balanced" and _contains(lower, PRIORITY_WORDS["unique"]):
        priority = "unique"
    budget = parse_budget(lower)
    user_interests = set(x.strip().lower() for x in (getattr(user, "interests", "") or "").split(",") if x.strip())
    user_brands = set(x.strip().lower() for x in (getattr(user, "brands", "") or "").split(",") if x.strip())
    scored = []
    for product in products:
        hay = _product_text(product)
        score = 0.0
        reasons = []
        for token in tokens:
            if token in hay:
                score += 7
        for category, cat_score in categories.items():
            if str(product.category).lower() == category.lower():
                score += 28 + 5 * cat_score
                reasons.append(category)
        if budget:
            low, high = budget
            price = int(product.price)
            if high is not None:
                if price <= high:
                    score += 24
                    reasons.append("в бюджете")
                else:
                    over = price - high
                    score -= min(35, over / max(high, 1) * 50)
            if low and price >= low:
                score += 6
        if goal:
            goal_hits = {"gaming": ("игры", "gaming", "гейм", "консоль", "gpu", "процессор"),
                         "work": ("работ", "офис", "мышь", "клавиат", "ноутбук", "ssd"),
                         "study": ("учеб", "книг", "ноутбук", "курс", "образован"),
                         "relax": ("развлеч", "музык", "аудио", "игр", "консол", "путешеств"),
                         "gift": ("подар", "аксессуары", "развлеч", "гаджет"),
                         "home": ("дом", "кух", "уборк", "мебель")}.get(goal, ())
            if any(x in hay for x in goal_hits):
                score += 17
                reasons.append(goal)
        if priority == "cheap":
            score += max(0, 18 - product.price / 5000)
        elif priority == "unique":
            # For unusual gifts, favor products that feel like an experience, hobby,
            # game, gadget or playful surprise instead of generic high-rated hardware.
            novelty_terms = ("игруш", "конструктор", "lego", "лего", "настольн", "хобби",
                             "гаджет", "камера", "консол", "приставк", "колонк", "проектор",
                             "телескоп", "робот", "квадрокоптер", "антистресс", "подар")
            if any(term in hay for term in novelty_terms):
                score += 18
                reasons.append("необычный подарок")
        elif priority == "performance":
            score += float(product.rating or 0) * 2 + (12 if getattr(product, "featured", False) else 0)
        elif priority == "quality":
            score += float(product.rating or 0) * 4
        else:
            score += float(product.rating or 0) * 2
            if getattr(product, "original_price", None) and product.original_price > product.price:
                score += 5
        if user_interests and any(i in hay for i in user_interests):
            score += 9
            reasons.append("ваши интересы")
        if user_brands and any(b in hay for b in user_brands):
            score += 6
            reasons.append("предпочтительный бренд")
        scored.append((score, product, reasons))
    if budget and budget[1] is not None:
        within = [row for row in scored if int(row[1].price) <= budget[1]]
        if within:
            scored = within
    if budget and budget[1] is not None:
        within = [row for row in scored if int(row[1].price) <= budget[1]]
        if within:
            scored = within
    # A recognized category is a hard search constraint, not a ranking bonus.
    # For example, a query for headphones must not return a phone or a processor
    # just because it has a high rating or matches a broad use-case.
    if categories:
        # "Подарки" describes the occasion, not a product category. When a
        # concrete category is also present (e.g. "смартфон в подарок"), use
        # that concrete category as the constraint instead of broad gift tags.
        category_constraints = [c for c in categories if c != "Подарки"] or list(categories)
        category_relevant = []
        for row in scored:
            product = row[1]
            product_category = str(getattr(product, "category", "") or "")
            hay = _product_text(product)
            matched_category = False
            for category in category_constraints:
                if category == "Подарки":
                    gift_categories = {
                        "gift", "игрушки", "игрушки и игры", "игровые консоли", "гаджеты", "хобби",
                        "развлечения", "аудио", "камеры", "спорт", "смарт-часы", "периферия",
                        "настольные игры", "образование", "подарки"
                    }
                    if product_category.casefold() in gift_categories or any(
                        term in hay for term in ("игруш", "конструктор", "настольн", "хобби",
                                                "гаджет", "сюрприз", "подар", "робот", "камера",
                                                "консол", "приставк", "антистресс", "квадрокоптер")
                    ):
                        matched_category = True
                        break
                if product_category.casefold() == category.casefold():
                    matched_category = True
                    break
                synonyms = CATEGORY_SYNONYMS.get(category, ())
                if any(_synonym_match(hay, synonym) for synonym in synonyms):
                    matched_category = True
                    break
            if matched_category:
                category_relevant.append(row)
        scored = category_relevant

    # A bare "подарок" is too broad to treat every item tagged "gift" as relevant.
    # Prefer approachable gift ideas; don't surface premium phones/watches merely
    # because an admin tagged them with the generic gift category.
    if _is_generic_gift_request(query):
        low_budget = budget[1] if budget and budget[1] is not None else 20000
        gift_terms = (
            "игруш", "конструктор", "lego", "лего", "настольн", "книга", "kindle",
            "колонк", "наушник", "гаджет", "головолом", "антистресс", "модель",
            "набор", "картина", "роз", "сюрприз", "мистери", "пазл", "хобби",
            "термос", "рюкзак", "проект", "лампа", "подарочн", "сувенир", "фигурк",
        )
        gift_matches = []
        for row in scored:
            product = row[1]
            hay = _product_text(product)
            if int(getattr(product, "price", 0) or 0) <= low_budget and any(term in hay for term in gift_terms):
                gift_matches.append(row)
        scored = gift_matches

    # Do not let rating, discount or a broad goal push unrelated products into
    # results for a concrete product-name query (e.g. "миньон").
    # When the query has no recognized category/goal, require lexical evidence
    # in the product's name/details/tags. Generic scoring alone is not relevance.
    if tokens and not categories and not goal:
        generic_tokens = {
            "дешево", "дешевле", "недорогой", "недорогая", "бюджетный",
            "лучший", "лучше", "качественный", "хороший", "подарок", "подарить",
            "необычное", "необычный", "оригинальное", "оригинальный", "что-то",
            "купить", "найти", "покажи", "подбери", "товар", "товары",
        }
        specific_tokens = {
            token for token in tokens
            if not token.isdigit() and token not in generic_tokens
        }
        if specific_tokens:
            relevant = []
            for row in scored:
                hay_tokens = set(tokenise(_product_text(row[1])))
                hits = sum(1 for token in specific_tokens
                           if token in hay_tokens or any(
                               len(token) >= 4 and len(candidate) >= 4
                               and __import__("difflib").SequenceMatcher(None, token, candidate).ratio() >= 0.84
                               for candidate in hay_tokens
                           ))
                coverage = hits / len(specific_tokens)
                if coverage >= 0.5:
                    relevant.append(row)
            scored = relevant

    scored.sort(key=lambda x: (x[0], float(getattr(x[1], "rating", 0) or 0)), reverse=True)
    return scored[:5], {"budget": budget, "categories": [x[0] for x in infer_categories(query)], "goal": goal, "priority": priority}


def filter_marketplace_offers(query, offers):
    """Apply the same intent boundaries to marketplace results as to catalog results."""
    text = normalize_text(query)
    categories = [name for name, _ in infer_categories(text)]
    budget = parse_budget(text)
    generic_gift = _is_generic_gift_request(text)
    result = []
    category_terms = {
        "Смартфоны": ("iphone", "айфон", "samsung", "galaxy", "pixel", "смартфон", "телефон", "redmi", "xiaomi", "honor", "realme"),
        "Наушники": ("наушник", "гарнитур", "headphone", "airpods", "buds", "sony wh", "jbl tune"),
        "Игровые консоли": ("playstation", "ps5", "ps4", "xbox", "nintendo switch", "приставка", "консоль"),
        "Комплектующие": ("процессор", "видеокарт", "geforce", "radeon", "ryzen", "core i", "ssd", "оперативная память", "материнская плата"),
        "Ноутбуки": ("ноутбук", "laptop", "macbook", "thinkpad", "vivobook", "ideapad", "zenbook"),
        "Смарт-часы": ("apple watch", "galaxy watch", "смарт-часы", "умные часы", "amazfit", "huawei watch"),
        "Игрушки и игры": ("игруш", "конструктор", "lego", "лего", "настольная игра", "пазл", "головолом", "антистресс", "робот", "фигурк"),
        "Аудио": ("колонк", "акустик", "динамик", "soundbar", "саундбар", "jbl charge", "marshall"),
    }
    gift_terms = (
        "игруш", "конструктор", "lego", "лего", "настольн", "книга", "kindle", "колонк",
        "наушник", "гаджет", "головолом", "антистресс", "модель", "набор", "картина", "роз",
        "сюрприз", "мистери", "пазл", "хобби", "термос", "рюкзак", "проект", "лампа",
        "подарочн", "сувенир", "фигурк", "плейстейшн", "playstation", "xbox", "приставк",
    )
    # A generic intent is useful, but it is not a reason to accept every result
    # that happens to contain the word "gift".
    concrete_categories = [c for c in categories if c not in ("Подарки", "Развлечения", "Путешествия")]
    for offer in offers:
        title = str(offer.get("name", "")).casefold().replace("ё", "е")
        price = offer.get("price")
        if budget and budget[1] is not None and price is not None and price > budget[1]:
            continue
        if generic_gift:
            limit = budget[1] if budget and budget[1] is not None else 20000
            if (price is not None and price > limit) or not any(term in title for term in gift_terms):
                continue
        elif concrete_categories:
            # If the user named a product category, require evidence in the offer title.
            matched = False
            for category in concrete_categories:
                terms = category_terms.get(category)
                if terms and any(term in title for term in terms):
                    matched = True
                    break
                if not terms:
                    synonyms = CATEGORY_SYNONYMS.get(category, ())
                    if any(_synonym_match(title, term) for term in synonyms):
                        matched = True
                        break
            if not matched:
                continue
        elif _contains(text, ("отдох", "отдых", "развлеч", "досуг")):
            leisure_terms = ("настольн", "игра", "пазл", "головолом", "кино", "квест", "консол", "приставк", "парк", "билет", "тур", "поход", "палатк", "велосипед", "самокат", "спорт")
            if not any(term in title for term in leisure_terms):
                continue
        result.append(offer)
    # A concise shortlist feels intentional and avoids flooding the response.
    result.sort(key=lambda item: (item.get("price") is None, item.get("price") or float("inf")))
    return result[:4]


def explain_recommendation(meta, matches):
    parts = []
    budget = meta["budget"]
    if budget and budget[1] is not None:
        parts.append(f"учёл лимит до {budget[1]:,} ₽".replace(",", " "))
    if meta["categories"]:
        parts.append("связал запрос с " + ", ".join(meta["categories"][:2]).lower())
    if meta["goal"]:
        labels = {"gaming": "игровым сценарием", "work": "работой", "study": "учёбой", "relax": "отдыхом", "gift": "подарком", "home": "домом"}
        parts.append("подстроил под " + labels.get(meta["goal"], meta["goal"]))
    if meta["priority"] != "balanced":
        labels = {"cheap": "экономию", "performance": "производительность", "quality": "качество", "unique": "необычные идеи"}
        parts.append("приоритет " + labels.get(meta["priority"], meta["priority"]))
    return "; ".join(parts) if parts else "по смыслу запроса и характеристикам каталога"


def answer(message, products, user=None):
    text = message.strip()
    lower = normalize_text(text)
    if not text:
        return {"ok": False, "answer": "Напишите вопрос или задачу — я попробую понять, что именно вам нужно.", "kind": "chat"}

    url_match = re.search(r"https?://[^\s]+", text)
    if url_match:
        url = url_match.group(0).rstrip(".,!?)]")
        rest = (text.replace(url, "").strip(" ,.!?"))
        msg = "Это ссылка. Могу открыть её в новой вкладке."
        if rest:
            msg += f" А остальной запрос я тоже понял как: «{rest}»."
        return {"ok": True, "answer": msg, "link": url, "kind": "link"}

    intent = parse_intent(text)
    if intent == "greeting":
        return {"ok": True, "answer": "Привет! Я SpendIt Assistant. Можешь писать обычным языком: «хочу отдохнуть до 5000», «нужен ноут для учёбы», «что взять для игр» — я сам разберу запрос и посмотрю, что есть в текущем каталоге.", "kind": "chat"}
    if intent == "thanks":
        return {"ok": True, "answer": "Всегда пожалуйста 😎 Если нужно, можешь просто описать задачу своими словами — формулировка не обязана быть точной.", "kind": "chat"}
    if intent == "identity":
        return {"ok": True, "answer": "Я встроенный помощник SpendIt. У меня нет полноценной большой языковой модели, но я умею разбирать смысловые подсказки, бюджеты, категории, цели покупки, приоритеты и подбирать варианты из активной базы.", "kind": "chat"}
    if intent == "capabilities":
        return {"ok": True, "answer": "Я понимаю обычные фразы, бюджеты («до 5000», «3000–10000»), задачи («для игр», «для дома», «на подарок»), синонимы категорий и могу объяснить, почему предложил товар. Также умею считать, распознавать ссылки, отвечать на базовые вопросы о времени и погоде и давать навигационные подсказки.", "kind": "chat"}
    faq = {
        "что такое инфляция": "Инфляция — это устойчивый рост общего уровня цен. Проще: со временем на ту же сумму обычно можно купить меньше товаров и услуг.",
        "что такое vpn": "VPN создаёт защищённое соединение между вашим устройством и VPN-сервером. Он может скрывать ваш реальный IP от сайтов и защищать трафик на небезопасных сетях, но не делает пользователя полностью анонимным.",
        "что такое api": "API — это набор правил, по которым одна программа обращается к другой. Например, сайт может запросить у API каталог товаров и получить данные в JSON.",
        "что такое flask": "Flask — лёгкий Python-фреймворк для создания веб-приложений. SpendIt как раз построен на Flask.",
    }
    for question, reply in faq.items():
        if question in lower:
            return {"ok": True, "answer": reply, "kind": "chat"}
    percent = re.search(r"(\d+(?:[.,]\d+)?)\s*%.*?от\s*(\d+(?:[.,]\d+)?)", lower)
    if percent:
        result = float(percent.group(1).replace(",", ".")) * float(percent.group(2).replace(",", ".")) / 100
        return {"ok": True, "answer": f"{percent.group(1)}% от {percent.group(2)} = {result:g}", "kind": "calculator"}
    if intent == "time":
        now = dt.datetime.now()
        return {"ok": True, "answer": f"Сейчас {now:%H:%M} по времени сервера SpendIt.", "kind": "chat"}
    if intent == "date":
        now = dt.datetime.now()
        return {"ok": True, "answer": f"Сегодня {now:%d.%m.%Y}.", "kind": "chat"}
    if intent == "weather":
        city_match = re.search(r"(?:в|для)\s+([а-яёa-z\- ]{2,40})", lower)
        city = city_match.group(1).strip() if city_match else "ваш город"
        return {"ok": True, "answer": f"Для «{city}» лучше открыть актуальный прогноз: я не буду выдумывать температуру без живых погодных данных.", "link": "https://www.google.com/search?q=" + quote_plus(city + " погода"), "kind": "weather"}

    expr = text.replace(" ", "")
    if re.fullmatch(r"[0-9()+\-*/%.]+", expr) and any(ch.isdigit() for ch in expr):
        try:
            value = _safe_calc(expr)
            return {"ok": True, "answer": f"Ответ: {value:g}" if isinstance(value, float) else f"Ответ: {value}", "kind": "calculator"}
        except Exception:
            pass

    matches, meta = rank_products(products, text, user)
    strong = [x for x in matches if x[0] > 8]
    if strong:
        explanation = explain_recommendation(meta, strong)
        category_text = ", ".join(meta["categories"][:2]) if meta["categories"] else "нужный сценарий"
        title = f"Подобрал варианты под {category_text.lower()}" if meta["categories"] else "Подобрал варианты по смыслу запроса"
        product_payload = []
        for score, p, reasons in strong[:4]:
            why = ", ".join(reasons[:3]) or "похож по задаче"
            product_payload.append({"id": p.id, "name": p.name, "price": p.price, "url": None, "why": why})
        answer_text = f"{title}. Я не требую точного названия товара: {explanation}."
        return {"ok": True, "answer": answer_text, "products": product_payload, "kind": "products", "meta": meta}

    if "не знаю" in lower or "что посовет" in lower or "посоветуй" in lower:
        return {"ok": True, "answer": "Опиши ситуацию своими словами: что хочешь получить, для чего это и сколько примерно готов потратить. Я переведу это в параметры каталога.", "kind": "chat"}
    return {"ok": True, "answer": "Я не нашёл достаточно сильного совпадения. Попробуй описать не название товара, а задачу — например «хочу расслабиться вечером до 5000», «нужен ноут для программирования» или «собери мне недорогой игровой набор».", "kind": "chat"}
