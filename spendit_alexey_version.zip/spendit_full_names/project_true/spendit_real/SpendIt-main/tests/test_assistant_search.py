import unittest
from types import SimpleNamespace

import assistant_engine


def product(pid, name, category, desc="", tags="", price=1000, rating=4.5):
    return SimpleNamespace(
        id=pid, name=name, category=category, desc=desc, details="",
        tags=tags, price=price, rating=rating, featured=True,
        original_price=None,
    )


class AssistantSearchRelevanceTests(unittest.TestCase):
    def setUp(self):
        self.products = [
            product(1, "Sony WH-1000XM5", "Наушники", "Беспроводные наушники"),
            product(2, "Apple iPhone 15", "Смартфоны", "Смартфон Apple"),
            product(3, "AMD Ryzen 7 7800X3D", "Комплектующие", "Процессор"),
            product(4, "Антистресс игрушка Миньон", "Игрушки",
                    "Мягкая игрушка миньон", "миньон игрушка"),
            product(5, "PlayStation 5 Slim", "Игровые консоли",
                    "Игровая приставка", "консоль игры", price=54990, rating=4.8),
            product(6, "Набор Lego Technic", "Хобби",
                    "Конструктор", "lego игрушка", price=8900, rating=4.7),
        ]

    def names(self, query):
        result = assistant_engine.answer(query, self.products)
        return [item["name"] for item in result.get("products", [])]

    def test_specific_name_does_not_return_unrelated_catalog_items(self):
        self.assertEqual(self.names("миньон"), ["Антистресс игрушка Миньон"])

    def test_unknown_query_returns_no_products(self):
        self.assertEqual(self.names("крокодил летающий"), [])

    def test_category_query_returns_only_that_category(self):
        self.assertEqual(self.names("наушники"), ["Sony WH-1000XM5"])

    def test_gift_request_can_find_a_toy_or_a_console_without_pc_parts(self):
        names = self.names("хочу крутую молодежную игрушка для брата")
        self.assertIn("PlayStation 5 Slim", names)
        self.assertIn("Набор Lego Technic", names)
        self.assertNotIn("AMD Ryzen 7 7800X3D", names)

    def test_powerful_smartphone_query_stays_in_smartphones(self):
        products = self.products + [product(7, "Apple Watch Series 9", "Смарт-часы", "умные часы", rating=4.9)]
        result = assistant_engine.answer("хочу мощный смартфон", products)
        names = [item["name"] for item in result.get("products", [])]
        self.assertTrue(names)
        self.assertTrue(all("iPhone" in name or "Galaxy" in name for name in names))

    def test_unusual_gift_can_return_hobby_and_playful_products(self):
        names = self.names("хочу подарить что-то необычное")
        self.assertTrue(any("Lego" in name or "Миньон" in name or "PlayStation" in name for name in names))
        self.assertNotIn("AMD Ryzen 7 7800X3D", names)

    def test_cheap_rest_uses_budget_and_entertainment_intent(self):
        products = self.products + [product(8, "Настольная игра для компании", "Развлечения", "весёлый отдых дома", price=1200)]
        result = assistant_engine.answer("хочу дёшево отдохнуть до 2000", products)
        names = [item["name"] for item in result.get("products", [])]
        self.assertIn("Настольная игра для компании", names)
        self.assertNotIn("AMD Ryzen 7 7800X3D", names)

    def test_generic_gift_does_not_return_expensive_flagships_from_gift_tag(self):
        products = [
            product(10, "Samsung Galaxy S24 128 ГБ", "gift", "Смартфон", price=64990),
            product(11, "Apple Watch Series 9", "gift", "Умные часы", price=37990),
            product(12, "Kindle Paperwhite", "gift", "Электронная книга", price=15990),
            product(13, "JBL Charge 5", "gift", "Портативная колонка", price=12990),
        ]
        names = [item[1].name for item in assistant_engine.rank_products(products, "подарок")[0]]
        self.assertIn("Kindle Paperwhite", names)
        self.assertIn("JBL Charge 5", names)
        self.assertNotIn("Samsung Galaxy S24 128 ГБ", names)
        self.assertNotIn("Apple Watch Series 9", names)

    def test_marketplace_gift_results_need_a_real_gift_item_and_reasonable_price(self):
        offers = [
            {"name": "Мыльные розы с гирляндой — подарок женщине", "price": 252},
            {"name": "Картина на стекле — подарок подруге", "price": 814},
            {"name": "Samsung Galaxy S24 подарок", "price": 64990},
            {"name": "Товар подарок", "price": 900},
        ]
        names = [item["name"] for item in assistant_engine.filter_marketplace_offers("подарок", offers)]
        self.assertIn("Мыльные розы с гирляндой — подарок женщине", names)
        self.assertIn("Картина на стекле — подарок подруге", names)
        self.assertNotIn("Samsung Galaxy S24 подарок", names)
        self.assertNotIn("Товар подарок", names)

    def test_marketplace_smartphone_query_does_not_return_watch_or_speaker(self):
        offers = [
            {"name": "Samsung Galaxy S24 128 ГБ", "price": 64990},
            {"name": "Apple Watch Series 9", "price": 37990},
            {"name": "JBL Charge 5", "price": 12990},
        ]
        names = [item["name"] for item in assistant_engine.filter_marketplace_offers("хочу мощный смартфон", offers)]
        self.assertEqual(names, ["Samsung Galaxy S24 128 ГБ"])

    def test_short_category_word_does_not_match_inside_another_word(self):
        self.assertEqual(assistant_engine.infer_goal("крокодил летающий"), None)


if __name__ == "__main__":
    unittest.main()
