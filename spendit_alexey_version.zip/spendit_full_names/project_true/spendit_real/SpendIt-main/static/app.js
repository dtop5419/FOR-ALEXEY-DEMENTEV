document.addEventListener('DOMContentLoaded', () => {
  const flash = document.querySelectorAll('.toast-spend');
  flash.forEach((el, i) => setTimeout(() => el.remove(), 4200 + i * 300));

  document.querySelectorAll('[data-favorite]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.favorite;
      const r = await fetch(`/favorite/toggle/${id}`, {method:'POST'});
      const data = await r.json();
      if (data.requires_auth && data.login_url) { window.location.href = data.login_url; return; }
      if (data.success) {
        btn.classList.toggle('active', data.favorite);
        btn.setAttribute('aria-label', data.favorite ? 'Убрать из избранного' : 'Добавить в избранное');
        btn.title = data.favorite ? 'Добавлено в избранное' : 'Удалено из избранного';
        const icon = btn.querySelector('i');
        if (icon) {
          icon.classList.toggle('bi-heart-fill', data.favorite);
          icon.classList.toggle('bi-heart', !data.favorite);
        }
        const label = btn.querySelector('span');
        if (label) label.textContent = data.favorite ? 'В избранном' : 'В избранное';
      }
    });
  });

  document.querySelectorAll('[data-budget]').forEach(chip => {
    chip.addEventListener('click', () => {
      const input = document.querySelector('#budget');
      if (input) { input.value = chip.dataset.budget; input.form.submit(); }
    });
  });

  const aiInput = document.querySelector('#aiQuery');
  const aiClear = document.querySelector('#aiClear');
  if (aiClear && aiInput) aiClear.addEventListener('click', () => { aiInput.value = ''; aiInput.focus(); });
  if (aiInput) {
    document.querySelectorAll('[data-query]').forEach(chip => chip.addEventListener('click', () => {
      aiInput.value = chip.dataset.query;
      aiInput.focus();
    }));
  }

  const assistantForm = document.querySelector('#assistantForm');
  const responseBox = document.querySelector('#assistantResponse');
  let assistantRequestNumber = 0;
  let assistantController = null;
  if (assistantForm && aiInput && responseBox) {
    assistantForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const message = aiInput.value.trim();
      if (!message) return;
      const requestNumber = ++assistantRequestNumber;
      if (assistantController) assistantController.abort();
      assistantController = new AbortController();
      responseBox.classList.remove('d-none');
      responseBox.innerHTML = '<span class="assistant-label">SpendIt Assistant</span><div class="assistant-thinking"><span></span><span></span><span></span> Анализирую запрос…</div>';
      try {
        const result = await fetch('/api/assistant', {
          method: 'POST', headers: {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest'},
          body: JSON.stringify({message}), signal: assistantController.signal
        });
        const data = await result.json();
        // A slower response to an older query must never replace the latest search.
        if (requestNumber !== assistantRequestNumber) return;
        if (!data.ok) throw new Error(data.answer || 'Ошибка');
        let html = `<span class="assistant-label">SpendIt Assistant · ${data.kind === 'products' ? 'каталог' : 'ответ'}</span><div>${escapeHtml(data.answer || '')}</div>`;
        if (data.marketplaces?.corrected_query) html += `<div class="assistant-correction">Искал по запросу: <strong>${escapeHtml(data.marketplaces.corrected_query)}</strong></div>`;
        if (data.products?.length) {
          html += '<div class="assistant-products">';
          for (const p of data.products.slice(0, 100)) {
            const safeUrl = safeProductUrl(p.url);
            const source = p.source ? ` · ${escapeHtml(p.source)}` : '';
            const image = p.image ? `<img class="assistant-product-image" src="${escapeHtml(p.image)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : '';
            let favoriteButton = '';
            if (p.source === 'Spendit' && p.id) {
              favoriteButton = `<button type="button" class="fav-btn assistant-fav-btn ${p.favorite ? 'active' : ''}" data-favorite="${Number(p.id)}" aria-label="${p.favorite ? 'Убрать из избранного' : 'В избранное'}"><i class="bi bi-heart-fill"></i></button>`;
            } else if (p.url && /^https?:\/\//i.test(p.url)) {
              favoriteButton = `<button type="button" class="fav-btn assistant-fav-btn ${p.favorite ? 'active' : ''}" data-marketplace-favorite data-name="${escapeHtml(p.name)}" data-price="${escapeHtml(p.price ?? '')}" data-url="${escapeHtml(p.url)}" data-image="${escapeHtml(p.image || '')}" data-source="${escapeHtml(p.source || 'Маркетплейс')}" aria-label="${p.favorite ? 'Убрать из избранного' : 'В избранное'}"><i class="bi bi-heart-fill"></i></button>`;
            }
            html += `<div class="assistant-product">${image}<div class="assistant-product-info"><a href="${safeUrl}" target="${p.source && p.source !== 'Spendit' ? '_blank' : '_self'}" rel="noopener">${escapeHtml(p.name)}</a><div class="muted small">${escapeHtml(p.why || 'подходит по запросу')}${source}</div></div><span class="price">${formatPrice(p.price)} ₽</span>${favoriteButton}</div>`;
          }
          html += '</div>';
        }
        if (data.link) {
          const label = data.kind === 'weather' ? 'Открыть погоду' : 'Открыть сайт';
          html += `<a class="btn btn-sm btn-gradient rounded-pill assistant-link" href="${data.link}" target="_blank" rel="noopener">${label} <i class="bi bi-box-arrow-up-right ms-1"></i></a>`;
        }
        responseBox.innerHTML = html;
      } catch (error) {
        if (error.name === 'AbortError' || requestNumber !== assistantRequestNumber) return;
        responseBox.innerHTML = '<span class="assistant-label">SpendIt Assistant</span><div>Не получилось обработать запрос. Попробуйте ещё раз.</div>';
      }
    });
  }

  // Assistant results are inserted dynamically, so use delegation for marketplace favorites.
  document.addEventListener('click', async (event) => {
    const btn = event.target.closest('[data-marketplace-favorite]');
    if (!btn) return;
    const payload = {
      name: btn.dataset.name,
      price: btn.dataset.price,
      url: btn.dataset.url,
      image: btn.dataset.image,
      source: btn.dataset.source
    };
    btn.disabled = true;
    try {
      const response = await fetch('/favorite/marketplace/toggle', {
        method: 'POST', headers: {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest'},
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (data.requires_auth && data.login_url) { window.location.href = data.login_url; return; }
      if (data.success) {
        btn.classList.toggle('active', data.favorite);
        btn.setAttribute('aria-label', data.favorite ? 'Убрать из избранного' : 'В избранное');
        btn.title = data.favorite ? 'Добавлено в избранное' : 'Удалено из избранного';
      }
    } catch (_) {
      // Leave the current state unchanged if the request fails.
    } finally {
      btn.disabled = false;
    }
  });

  function safeProductUrl(value) {
    try {
      const parsed = new URL(value, window.location.origin);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') return escapeHtml(parsed.href);
    } catch (_) {}
    return '#';
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
  }
  function formatPrice(value) { return Number(value).toLocaleString('ru-RU'); }
});

(() => {
  const body = document.body;
  const buttons = document.querySelectorAll('[data-theme]');
  const stored = localStorage.getItem('spendit-theme');
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const apply = (theme) => {
    body.dataset.theme = theme;
    localStorage.setItem('spendit-theme', theme);
    document.querySelectorAll('.theme-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.theme === theme));
  };
  apply(stored || (prefersDark ? 'dark' : 'light'));
  document.querySelectorAll('.theme-btn').forEach(btn => btn.addEventListener('click', () => apply(btn.dataset.theme)));
})();
